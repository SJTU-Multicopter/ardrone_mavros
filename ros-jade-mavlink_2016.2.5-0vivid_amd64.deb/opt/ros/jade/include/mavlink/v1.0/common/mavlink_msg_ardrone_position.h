// MESSAGE ARDRONE_POSITION PACKING

#define MAVLINK_MSG_ID_ARDRONE_POSITION 213

typedef struct __mavlink_ardrone_position_t
{
 float robot_x; /*< X position of the robot*/
 float robot_y; /*< Y position of the robot*/
 float catch_x; /*< X position of for catching*/
 float catch_y; /*< Y position of for catching*/
 uint8_t moving; /*< Flag whether the drone move or not*/
} mavlink_ardrone_position_t;

#define MAVLINK_MSG_ID_ARDRONE_POSITION_LEN 17
#define MAVLINK_MSG_ID_213_LEN 17

#define MAVLINK_MSG_ID_ARDRONE_POSITION_CRC 134
#define MAVLINK_MSG_ID_213_CRC 134



#define MAVLINK_MESSAGE_INFO_ARDRONE_POSITION { \
	"ARDRONE_POSITION", \
	5, \
	{  { "robot_x", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ardrone_position_t, robot_x) }, \
         { "robot_y", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ardrone_position_t, robot_y) }, \
         { "catch_x", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ardrone_position_t, catch_x) }, \
         { "catch_y", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ardrone_position_t, catch_y) }, \
         { "moving", NULL, MAVLINK_TYPE_UINT8_T, 0, 16, offsetof(mavlink_ardrone_position_t, moving) }, \
         } \
}


/**
 * @brief Pack a ardrone_position message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param moving Flag whether the drone move or not
 * @param robot_x X position of the robot
 * @param robot_y Y position of the robot
 * @param catch_x X position of for catching
 * @param catch_y Y position of for catching
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ardrone_position_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t moving, float robot_x, float robot_y, float catch_x, float catch_y)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_ARDRONE_POSITION_LEN];
	_mav_put_float(buf, 0, robot_x);
	_mav_put_float(buf, 4, robot_y);
	_mav_put_float(buf, 8, catch_x);
	_mav_put_float(buf, 12, catch_y);
	_mav_put_uint8_t(buf, 16, moving);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#else
	mavlink_ardrone_position_t packet;
	packet.robot_x = robot_x;
	packet.robot_y = robot_y;
	packet.catch_x = catch_x;
	packet.catch_y = catch_y;
	packet.moving = moving;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_ARDRONE_POSITION;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN, MAVLINK_MSG_ID_ARDRONE_POSITION_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif
}

/**
 * @brief Pack a ardrone_position message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param moving Flag whether the drone move or not
 * @param robot_x X position of the robot
 * @param robot_y Y position of the robot
 * @param catch_x X position of for catching
 * @param catch_y Y position of for catching
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ardrone_position_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t moving,float robot_x,float robot_y,float catch_x,float catch_y)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_ARDRONE_POSITION_LEN];
	_mav_put_float(buf, 0, robot_x);
	_mav_put_float(buf, 4, robot_y);
	_mav_put_float(buf, 8, catch_x);
	_mav_put_float(buf, 12, catch_y);
	_mav_put_uint8_t(buf, 16, moving);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#else
	mavlink_ardrone_position_t packet;
	packet.robot_x = robot_x;
	packet.robot_y = robot_y;
	packet.catch_x = catch_x;
	packet.catch_y = catch_y;
	packet.moving = moving;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_ARDRONE_POSITION;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN, MAVLINK_MSG_ID_ARDRONE_POSITION_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif
}

/**
 * @brief Encode a ardrone_position struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ardrone_position C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ardrone_position_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ardrone_position_t* ardrone_position)
{
	return mavlink_msg_ardrone_position_pack(system_id, component_id, msg, ardrone_position->moving, ardrone_position->robot_x, ardrone_position->robot_y, ardrone_position->catch_x, ardrone_position->catch_y);
}

/**
 * @brief Encode a ardrone_position struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ardrone_position C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ardrone_position_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ardrone_position_t* ardrone_position)
{
	return mavlink_msg_ardrone_position_pack_chan(system_id, component_id, chan, msg, ardrone_position->moving, ardrone_position->robot_x, ardrone_position->robot_y, ardrone_position->catch_x, ardrone_position->catch_y);
}

/**
 * @brief Send a ardrone_position message
 * @param chan MAVLink channel to send the message
 *
 * @param moving Flag whether the drone move or not
 * @param robot_x X position of the robot
 * @param robot_y Y position of the robot
 * @param catch_x X position of for catching
 * @param catch_y Y position of for catching
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ardrone_position_send(mavlink_channel_t chan, uint8_t moving, float robot_x, float robot_y, float catch_x, float catch_y)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_ARDRONE_POSITION_LEN];
	_mav_put_float(buf, 0, robot_x);
	_mav_put_float(buf, 4, robot_y);
	_mav_put_float(buf, 8, catch_x);
	_mav_put_float(buf, 12, catch_y);
	_mav_put_uint8_t(buf, 16, moving);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ARDRONE_POSITION, buf, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN, MAVLINK_MSG_ID_ARDRONE_POSITION_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ARDRONE_POSITION, buf, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif
#else
	mavlink_ardrone_position_t packet;
	packet.robot_x = robot_x;
	packet.robot_y = robot_y;
	packet.catch_x = catch_x;
	packet.catch_y = catch_y;
	packet.moving = moving;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ARDRONE_POSITION, (const char *)&packet, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN, MAVLINK_MSG_ID_ARDRONE_POSITION_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ARDRONE_POSITION, (const char *)&packet, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_ARDRONE_POSITION_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ardrone_position_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t moving, float robot_x, float robot_y, float catch_x, float catch_y)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_float(buf, 0, robot_x);
	_mav_put_float(buf, 4, robot_y);
	_mav_put_float(buf, 8, catch_x);
	_mav_put_float(buf, 12, catch_y);
	_mav_put_uint8_t(buf, 16, moving);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ARDRONE_POSITION, buf, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN, MAVLINK_MSG_ID_ARDRONE_POSITION_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ARDRONE_POSITION, buf, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif
#else
	mavlink_ardrone_position_t *packet = (mavlink_ardrone_position_t *)msgbuf;
	packet->robot_x = robot_x;
	packet->robot_y = robot_y;
	packet->catch_x = catch_x;
	packet->catch_y = catch_y;
	packet->moving = moving;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ARDRONE_POSITION, (const char *)packet, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN, MAVLINK_MSG_ID_ARDRONE_POSITION_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ARDRONE_POSITION, (const char *)packet, MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE ARDRONE_POSITION UNPACKING


/**
 * @brief Get field moving from ardrone_position message
 *
 * @return Flag whether the drone move or not
 */
static inline uint8_t mavlink_msg_ardrone_position_get_moving(const mavlink_message_t* msg)
{
	return _MAV_RETURN_uint8_t(msg,  16);
}

/**
 * @brief Get field robot_x from ardrone_position message
 *
 * @return X position of the robot
 */
static inline float mavlink_msg_ardrone_position_get_robot_x(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field robot_y from ardrone_position message
 *
 * @return Y position of the robot
 */
static inline float mavlink_msg_ardrone_position_get_robot_y(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field catch_x from ardrone_position message
 *
 * @return X position of for catching
 */
static inline float mavlink_msg_ardrone_position_get_catch_x(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field catch_y from ardrone_position message
 *
 * @return Y position of for catching
 */
static inline float mavlink_msg_ardrone_position_get_catch_y(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Decode a ardrone_position message into a struct
 *
 * @param msg The message to decode
 * @param ardrone_position C-struct to decode the message contents into
 */
static inline void mavlink_msg_ardrone_position_decode(const mavlink_message_t* msg, mavlink_ardrone_position_t* ardrone_position)
{
#if MAVLINK_NEED_BYTE_SWAP
	ardrone_position->robot_x = mavlink_msg_ardrone_position_get_robot_x(msg);
	ardrone_position->robot_y = mavlink_msg_ardrone_position_get_robot_y(msg);
	ardrone_position->catch_x = mavlink_msg_ardrone_position_get_catch_x(msg);
	ardrone_position->catch_y = mavlink_msg_ardrone_position_get_catch_y(msg);
	ardrone_position->moving = mavlink_msg_ardrone_position_get_moving(msg);
#else
	memcpy(ardrone_position, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_ARDRONE_POSITION_LEN);
#endif
}
